<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void { Schema::table('users', function(Blueprint $table){$table->string('phone')->nullable()->unique();$table->string('whatsapp_number')->nullable();$table->string('role')->default('customer')->index();$table->string('referral_code')->nullable()->unique();}); }
 public function down(): void { Schema::table('users', function(Blueprint $table){$table->dropColumn(['phone','whatsapp_number','role','referral_code']);}); }
};